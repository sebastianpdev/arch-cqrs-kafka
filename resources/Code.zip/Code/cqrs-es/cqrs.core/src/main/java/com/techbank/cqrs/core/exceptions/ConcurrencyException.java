package com.techbank.cqrs.core.exceptions;

public class ConcurrencyException extends RuntimeException {
}

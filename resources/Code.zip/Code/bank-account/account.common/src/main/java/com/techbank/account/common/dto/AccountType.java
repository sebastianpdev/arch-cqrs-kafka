package com.techbank.account.common.dto;

public enum AccountType {
    SAVINGS, CURRENT
}